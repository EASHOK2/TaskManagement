export interface TaskUser {
    id: number;
    firstName: string ;
    lastName: string ;
    email: string;
    password: string;
    role: string;
}